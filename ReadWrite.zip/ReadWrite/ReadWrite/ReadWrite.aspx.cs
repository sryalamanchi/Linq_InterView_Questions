﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Web.Configuration;
using System.Data.SqlClient;
using Microsoft.Reporting.WebForms;

namespace ReadWrite
{
    public partial class ReadWrite : System.Web.UI.Page
    {


        string Read_From_Path = string.Empty;
        string Write_To_Path = string.Empty;
        string DownloadFile_Path = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {

                Session["ssn_dtReport_Item"] = null;

            }
        }

        protected void btnRead_Click(object sender, EventArgs e)
        {
            DataTable _dt = new DataTable();
            _dt.Columns.Add("Model_Name");
            _dt.Columns.Add("IMEI1");
            _dt.Columns.Add("IMEI2");
            _dt.Columns.Add("SR_NO");
            try
            {
                DownloadFile_Path = "C:\\demo_download\\Downloadfile.csv";
                using (var rd = new StreamReader(DownloadFile_Path))
                {
                    while (!rd.EndOfStream)
                    {
                        var splits = rd.ReadLine().Split(',');
                        if (splits[0].ToUpper().Trim() == "MODEL_NAME")
                            continue;
                        _dt.Rows.Add(splits[0], splits[1], splits[2], splits[3]);
                    }
                    if (_dt.Rows.Count > 0)
                    {
                        GrdRead.DataSource = _dt;
                        GrdRead.DataBind();
                    }
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        protected void btnDownload_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable _dt = new DataTable();
                _dt.Columns.Add("Model_Name");
                _dt.Columns.Add("IMEI1");
                _dt.Columns.Add("IMEI2");
                _dt.Columns.Add("SR_NO");

                DownloadFile_Path = "C:\\demo_download\\Downloadfile.csv";

                if (!File.Exists(HttpContext.Current.Server.MapPath(DownloadFile_Path)))
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('File is not found at location')", true);
                }

                FileInfo fileInfo = new FileInfo(DownloadFile_Path);
                if (fileInfo.Exists)
                {
                    using (var rd = new StreamReader(DownloadFile_Path))
                    {
                        while (!rd.EndOfStream)
                        {
                            var splits = rd.ReadLine().Split(',');
                            if (splits[0].ToUpper().Trim() == "MODEL_NAME")
                                continue;
                            _dt.Rows.Add(splits[0], splits[1], splits[2], splits[3]);
                        }
                    }
                    if (_dt.Rows.Count > 0)
                    {
                        dgvFile.DataSource = _dt;
                        dgvFile.DataBind();
                    }
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('File is not found at location')", true);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        protected void BbnBox_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = WebConfigurationManager.ConnectionStrings["ConnectionSql"].ConnectionString;
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                string Query = "select * from TBL_BOX";
                SqlCommand _cmd = new SqlCommand(Query, con);
                SqlDataAdapter sqlda = new SqlDataAdapter(_cmd);
                DataTable _dt = new DataTable();
                sqlda.Fill(_dt);
                gvBox.DataSource = _dt;
                Session["ssn_dtReport_Item"] = _dt;
                gvBox.DataBind();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnShowReport_Click(object sender, EventArgs e)
        {
            try
            {
                
                DataTable _dt = new DataTable();
                if (gvBox.Rows.Count > 0)
                {
                    if (Session["ssn_dtReport_Item"] != null)
                    {
                        _dt = (DataTable)Session["ssn_dtReport_Item"];
                      
                        ReportViewer1.ProcessingMode = ProcessingMode.Local;
                        ReportViewer1.LocalReport.ReportPath = Server.MapPath("RptBox.rdlc");
                        ReportDataSource datasource = new ReportDataSource("DataSet1", _dt);
                        ReportViewer1.LocalReport.DataSources.Clear();
                        ReportViewer1.LocalReport.DataSources.Add(datasource);
                    }
                }

            }
            catch (Exception ex)
            {
                throw;
            }
        }

    }
}